const SCHEMA = {
 '01_SO_MASTER':['id','so','customer','po','due','owner','folder','status','source_system','source_key','created_at','updated_at'],
 '02_SO_ITEM_MATERIAL':['id','case_id','sku','material','supplier','supplier_po','tier','folder','source_system','source_key'],
 '03_EVIDENCE_REQUIREMENT':['id','material','evidence','department','tier','enabled'],
 '04_EVIDENCE_TRACKER':['id','case_id','material_id','evidence','department','owner','due','status','document_id','note','updated_at','calendar_event_id'],
 '05_OWNER_MASTER':['email','name','department','role','active'],
 '06_DOCUMENT_REGISTER':['id','case_id','task_id','kind','name','file_id','version','status','uploaded_by','created_at'],
 '07_AI_REVIEW_QUEUE':['id','case_id','document_id','finding','status','reviewer'],
 '08_ACTIVITY_LOG':['id','timestamp','actor','action','case_id','entity_id','previous','next'],
 '09_CONFIG':['key','value'],
 '10_INTEGRATION_LOG':['batch_id','source','timestamp','status','records','error'],
 '11_INTEGRATION_ERROR':['batch_id','source_key','error','retry_status']
};
const PREPARED = {
 sheetId:'1xura5W6coeGeJsc1zQMP6Emw_QMTv5XAf0bqpC5Uk3A',
 rootFolderId:'1BWXpf-L6yBPQtXbskoQKMfN890aZXCJg',
 calendarId:'44c53155b661c93b06c6ee49bd9cce5764a91fa80cc57c805de639d3483cfce2@group.calendar.google.com'
};
function attachPreparedSheet(){return connectPreparedSheet_(false);}
function reconnectPreparedSheet(){return connectPreparedSheet_(true);}
function diagnoseConnection(){
 const p=PropertiesService.getScriptProperties();
 const result={currentSheetId:p.getProperty('DB_ID')||'(not set)',expectedSheetId:PREPARED.sheetId,previousSheetId:p.getProperty('PREVIOUS_DB_ID')||'(not set)'};
 console.log(JSON.stringify(result));
 return result;
}
function connectPreparedSheet_(allowSwitch){
 const p=PropertiesService.getScriptProperties();
 const existing=p.getProperty('DB_ID');
 if(existing&&existing!==PREPARED.sheetId&&!allowSwitch)throw Error('This script is already connected to a different Sheet. Run reconnectPreparedSheet() to switch to the prepared EUDR workbook; the previous ID will be saved.');
 const db=SpreadsheetApp.openById(PREPARED.sheetId);
 Object.keys(SCHEMA).forEach(n=>{
   const s=db.getSheetByName(n);if(!s)throw Error('Missing tab '+n);
   const actual=s.getRange(1,1,1,SCHEMA[n].length).getValues()[0];
   if(JSON.stringify(actual)!==JSON.stringify(SCHEMA[n]))throw Error('Header mismatch in '+n);
 });
 DriveApp.getFolderById(PREPARED.rootFolderId).getName();
 if(!CalendarApp.getCalendarById(PREPARED.calendarId))throw Error('Calendar unavailable to the deploying account');
 const email=Session.getEffectiveUser().getEmail().toLowerCase();if(!email)throw Error('Deploying account email unavailable');
 const properties={DB_ID:PREPARED.sheetId,ROOT_ID:PREPARED.rootFolderId,CALENDAR_ID:PREPARED.calendarId};
 if(existing&&existing!==PREPARED.sheetId)properties.PREVIOUS_DB_ID=existing;
 p.setProperties(properties);
 if(!rows_('05_OWNER_MASTER').some(x=>String(x.email).toLowerCase()===email))add_('05_OWNER_MASTER',{email,name:email,department:'Marketing',role:'ADMIN',active:'YES'});
 if(existing!==PREPARED.sheetId)audit_(existing?'RECONNECT_PREPARED':'ATTACH_PREPARED', '', '', existing||'', 'Configured existing Sheet / Drive / Calendar',email);
 return {spreadsheet:db.getUrl(),folder:DriveApp.getFolderById(PREPARED.rootFolderId).getUrl(),calendar:PREPARED.calendarId};
}
function setupFromProperties(){
 const p=PropertiesService.getScriptProperties();
 return setup({sheetId:p.getProperty('INSTALL_SHEET_ID'),rootFolderId:p.getProperty('INSTALL_ROOT_FOLDER_ID')});
}
function setup(config){
 if(config===undefined)return attachPreparedSheet();
 if(!config||!config.sheetId||!config.rootFolderId) throw Error('For a new blank workbook, supply both Sheet and root Folder IDs.');
 const p=PropertiesService.getScriptProperties();
 if(p.getProperty('DB_ID')) throw Error('Already initialized; setup never overwrites existing data.');
 const email=Session.getEffectiveUser().getEmail(); if(!email) throw Error('Google identity required');
 const db=SpreadsheetApp.openById(config.sheetId.trim());
 const root=DriveApp.getFolderById(config.rootFolderId.trim());
 const sheets=db.getSheets();
 if(sheets.length!==1||sheets[0].getLastRow()>0||sheets[0].getLastColumn()>0)throw Error('Setup requires a dedicated blank spreadsheet with one empty tab. Existing data was not changed.');
 // Remove the blank tab only after the new schema is fully created.
 Object.keys(SCHEMA).forEach(n=>{const s=db.insertSheet(n);s.appendRow(SCHEMA[n]);s.setFrozenRows(1);s.getRange(1,1,1,SCHEMA[n].length).setBackground('#123d36').setFontColor('white').setFontWeight('bold');});
 db.deleteSheet(sheets[0]);db.setSpreadsheetTimeZone('Asia/Ho_Chi_Minh');
 p.setProperties({DB_ID:db.getId(),ROOT_ID:root.getId()});
 add_('05_OWNER_MASTER',{email,name:email,department:'Marketing',role:'ADMIN',active:'YES'});
 ['Sales order','COO','INV','PL','BL','Supplier FSC license','FSC Cert','Transport invoice','GEO location'].forEach((e,i)=>add_('03_EVIDENCE_REQUIREMENT',{id:'R'+i,material:'*',evidence:e,department:e==='GEO location'?'Sourcing':'Purchasing',tier:'DIRECT',enabled:'YES'}));
 add_('09_CONFIG',{key:'RULES_CONFIRMED',value:'NO'});
 add_('09_CONFIG',{key:'REMINDERS_ENABLED',value:'NO'});
 audit_('SETUP','','', '', 'MVP initialized; draft requirement rules');
 return {spreadsheet:db.getUrl(),folder:root.getUrl()};
}
function doGet(){return HtmlService.createHtmlOutput('KODA EUDR WORKSPACE API. Open the Netlify site to use the workspace.').setTitle('KODA EUDR WORKSPACE');}
var DB_MEMO_=null,DB_MEMO_ID_='',SHEET_MEMO_={},TABLE_CACHE_={},TABLE_INDEX_CACHE_={},TZ_MEMO_='';
function resetDbCache_(){DB_MEMO_=null;DB_MEMO_ID_='';SHEET_MEMO_={};TABLE_INDEX_CACHE_={};TZ_MEMO_='';}
function db_(){const id=PropertiesService.getScriptProperties().getProperty('DB_ID');if(!id)throw Error('Run setup first');if(DB_MEMO_&&DB_MEMO_ID_===id)return DB_MEMO_;DB_MEMO_=SpreadsheetApp.openById(id);DB_MEMO_ID_=id;SHEET_MEMO_={};return DB_MEMO_;}
function sheet_(n){const d=db_();if(d===DB_MEMO_&&SHEET_MEMO_[n])return SHEET_MEMO_[n];if(d===DB_MEMO_&&!Object.keys(SHEET_MEMO_).length){try{d.getSheets().forEach(s=>{SHEET_MEMO_[s.getName()]=s;});if(SHEET_MEMO_[n])return SHEET_MEMO_[n];}catch(e){}}const s=d.getSheetByName(n);if(d===DB_MEMO_&&s)SHEET_MEMO_[n]=s;return s;}
function rows_(n){if(TABLE_CACHE_[n])return TABLE_CACHE_[n].map(x=>({...x}));const s=sheet_(n);if(!s)return [];const db=db_(),tz=TZ_MEMO_||(TZ_MEMO_=db.getSpreadsheetTimeZone());let v;if(n==='08_ACTIVITY_LOG'&&typeof s.getLastRow==='function'&&typeof s.getRange==='function'){try{const lastRow=s.getLastRow(),lastCol=s.getLastColumn();if(lastRow<=1)v=[];else if(lastRow<=501)v=s.getDataRange().getValues();else{const h=s.getRange(1,1,1,lastCol).getValues(),rows=s.getRange(lastRow-499,1,500,lastCol).getValues();v=[h[0],...rows];}}catch(e){v=s.getDataRange().getValues();}}else{v=s.getDataRange().getValues();}const h=v.shift()||[];const result=v.filter(r=>r[0]).map(r=>Object.fromEntries(h.filter(Boolean).map((k,i)=>[k,r[i] instanceof Date&&k==='due'?Utilities.formatDate(r[i],tz,'yyyy-MM-dd'):r[i] instanceof Date?r[i].toISOString():r[i]])));TABLE_CACHE_[n]=result;return result.map(x=>({...x}));}
function safe_(v){return typeof v==='string' && /^[=+@\-]/.test(v)?"'"+v:v;}
function add_(n,o){const record=Object.fromEntries(SCHEMA[n].map(k=>[k,o[k]===undefined?'':o[k]]));sheet_(n).appendRow(SCHEMA[n].map(k=>safe_(record[k])));if(TABLE_CACHE_[n])TABLE_CACHE_[n].push(record);}
function patch_(n,id,o){const s=sheet_(n),v=s.getDataRange().getValues(),i=v.findIndex((r,j)=>j>0&&r[0]===id);if(i<1)throw Error('Record not found');const keys=Object.keys(o),cols=keys.map(k=>{const col=SCHEMA[n].indexOf(k);if(col<0)throw Error('Unknown field');return col;});if(keys.length===1){s.getRange(i+1,cols[0]+1).setValue(safe_(o[keys[0]]));}else if(keys.length>1){const row=v[i].slice(0,SCHEMA[n].length);while(row.length<SCHEMA[n].length)row.push('');keys.forEach((k,idx)=>{row[cols[idx]]=safe_(o[k]);});s.getRange(i+1,1,1,SCHEMA[n].length).setValues([row]);}const cached=TABLE_CACHE_[n]&&TABLE_CACHE_[n].find(x=>x[SCHEMA[n][0]]===id);if(cached)Object.assign(cached,o);else delete TABLE_CACHE_[n];}
function delete_(n,id){delete TABLE_CACHE_[n];const s=sheet_(n),v=s.getDataRange().getValues(),i=v.findIndex((r,j)=>j>0&&r[0]===id);if(i<1)throw Error('Record not found');s.deleteRow(i+1);}
function uid_(){return Utilities.getUuid();}
function now_(){return new Date().toISOString();}
function user_(){
 const email=String(BRIDGE_ACTOR||Session.getActiveUser().getEmail()||'').toLowerCase();
 const u=rows_('05_OWNER_MASTER').find(x=>String(x.email).toLowerCase()===email&&x.active==='YES');
 if(!u)fail_('AUTH_REQUIRED','User is not active');
 if(BRIDGE_AUTH_UID&&(u.auth_provider!=='FIREBASE'||u.auth_uid!==BRIDGE_AUTH_UID))fail_('AUTH_REQUIRED','Firebase account is not provisioned for this owner');
 if(u.auth_provider==='FIREBASE'&&(!BRIDGE_AUTH_UID||u.auth_uid!==BRIDGE_AUTH_UID))fail_('AUTH_REQUIRED','Account identity mismatch');
 if(u.must_change_password==='YES'&&!['bootstrap','recordLogin','authState','authPasswordChanged'].includes(BRIDGE_ACTION))fail_('PASSWORD_CHANGE_REQUIRED','Change password before accessing the workspace');
 if(!ROLES_.includes(u.role))fail_('PERMISSION_DENIED','Unknown role');
 if(u.role==='SUPPLIER_USER'&&!rows_('14_SUPPLIERS').some(s=>s.id===u.supplier_id&&s.active==='YES'))fail_('PERMISSION_DENIED','Supplier disabled');
 return u;
}
function manager_(u){return ['ADMIN','MARKETING'].includes(u.role);}
function requireManager_(){return requireCapability_('ORDER_EDIT');}
function lock_(fn){const l=LockService.getScriptLock();l.waitLock(20000);try{return fn();}finally{l.releaseLock();}}
function audit_(action,c,e,previous,next,actor){const email=actor||BRIDGE_ACTOR||Session.getEffectiveUser().getEmail(),u=rows_('05_OWNER_MASTER').find(x=>x.email===email),order=c&&rows_('01_SO_MASTER').find(x=>x.id===c);let comment='';try{comment=JSON.parse(next||'{}').comment||'';}catch(ignore){}add_('08_ACTIVITY_LOG',{id:uid_(),timestamp:now_(),actor:email,role:u?u.role:'SYSTEM',action,object_type:action.split('_')[0],case_id:c,order_no:order?order.so:'',entity_id:e,previous,next,comment});}
function config_(k){return (rows_('09_CONFIG').find(x=>x.key===k)||{}).value;}
